package practicasPlayground;

import java.util.Scanner;

public class practica {

    // EJERCICIO SCANNER
    /*
    public static void main(String[] args) {

        Scanner scanner;
        scanner = new Scanner(System.in);



        System.out.println("Ingrese su número favorito");
        int num = scanner.nextInt();

        System.out.println("Ingrese su nombre por consola");
        String nombre = scanner.next();
        char inicialNombre = nombre.charAt(0);

        System.out.println("Ingrese su apellido por consola");
        String apellido = scanner.next();
        char inicialApellido = apellido.charAt(0);

        System.out.println("Su firma entonces sería\n" + inicialNombre + inicialApellido + "(" + num + ")" );

    }
    */

    // EJERCICIO FUNCIONES
    /*
    // declaro la función fuera del main
    static boolean esDivisible(int numero1, int numero2) {
        if (numero1%numero2==0) {
            return true;
        }
        else {
            return false;
        }
    }

    // adentro del main llamo a la funcion con los valores a evaluar
    public static void main(String[] args) {
        System.out.println(esDivisible(11,2));
    }
    */


}
