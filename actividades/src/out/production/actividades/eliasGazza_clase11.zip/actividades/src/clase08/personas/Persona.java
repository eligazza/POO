package clase08.personas;

import java.time.LocalDate;
import java.time.Period;

public class Persona {

    // Atributos
    protected String nombre;
    protected String apellido;

    // Constructor
    public Persona(String nombre, String apellido) {
        this.nombre     = nombre;
        this.apellido   = apellido;
    }

    // Metodo

}
