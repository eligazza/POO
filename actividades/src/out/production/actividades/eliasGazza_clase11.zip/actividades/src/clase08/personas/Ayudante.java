package clase08.personas;

public class Ayudante extends Profesor {

    // Constructor
    public Ayudante(String nombre, String apellido, String materia) {
        super(nombre, apellido, materia);
    }

    // Metodos
    public void tomarAsistencia() {};

}
