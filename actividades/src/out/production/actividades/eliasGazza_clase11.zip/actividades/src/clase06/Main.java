package clase06;

public class Main {

    public static void main(String[] args) {

        // Creo el objeto Cody
        // Perro cody = new Perro("Cody","callejera", 2000, false, 21.0, false, false);
        Perro cody = new Perro("Cody","callejera");
        cody.setAnioNacimiento(2000);
        cody.setPeso(20.0);

    }
}
