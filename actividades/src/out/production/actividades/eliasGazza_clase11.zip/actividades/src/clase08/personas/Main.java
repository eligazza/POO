package clase08.personas;

import java.time.LocalDate;

public class Main {

    public static void main(String[] args) {

        // Demostracion
        Estudiante pepito = new Estudiante(
                "Elias",
                "Gazza",
                "Licenciatura en Genética",
                9.8
        );

        Experto pabloVidal = new Experto(
                "Pablo",
                "Vidal",
                "POO",
                "Herencia"
        );

    }
}
